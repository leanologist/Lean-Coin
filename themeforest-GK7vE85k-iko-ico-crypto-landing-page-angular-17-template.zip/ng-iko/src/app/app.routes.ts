import { Routes } from '@angular/router';
import { HomeMainComponent } from './pages/home/home-main/home-main.component';
import { HomeTwoComponent } from './pages/home/home-two/home-two.component';
import { ContactComponent } from './pages/contact/contact.component';
import { BlogComponent } from './pages/blog/blog.component';
import { BlogDetailsComponent } from './pages/blog-details/blog-details.component';

export const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path:'home',children:[
    {path:'',component:HomeMainComponent,title:'Home Main - IKO'},
    {path:'home-two',component:HomeTwoComponent,title:'Home two - IKO'},
  ]},
  {path:'blog',component:BlogComponent,title:'Blog - IKO'},
  {path:'blog-details/:id',component:BlogDetailsComponent,title:'Blog Details - IKO'},
  {path:'contact',component:ContactComponent,title:'Contact - IKO'},
];
