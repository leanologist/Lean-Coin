import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { of, switchMap } from 'rxjs';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { HeaderThreeComponent } from '../../shared/layout/header/header-three/header-three.component';
import { BreadcrumbComponent } from '../../shared/components/breadcrumb/breadcrumb.component';
import { DocumentAreaComponent } from '../../shared/components/document-area/document-area.component';
import { FooterThreeComponent } from '../../shared/layout/footer/footer-three/footer-three.component';
import { IBlogDT } from '../../shared/types/blog-d-t';
import { UtilsService } from '../../shared/services/utils.service';
import { BlogSidebarComponent } from '../../shared/components/blog/blog-sidebar/blog-sidebar.component';

@Component({
  selector: 'app-blog-details',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    HeaderThreeComponent,
    BreadcrumbComponent,
    DocumentAreaComponent,
    BlogSidebarComponent,
    FooterThreeComponent,
  ],
  templateUrl: './blog-details.component.html',
  styleUrl: './blog-details.component.css'
})
export class BlogDetailsComponent {

  public blog: IBlogDT | null | undefined;
  public related_blogs:IBlogDT[] = [];

  constructor(
    private route: ActivatedRoute,
    public utilsService: UtilsService,
    private router: Router
  ) { }

  ngOnInit() {

    this.route.paramMap.pipe(
      switchMap(params => {
        const blogId = params.get('id');
        if (blogId) {
          return this.utilsService.getBlogById(blogId);
        }
        return of<IBlogDT | null>(null); // Emit null if there's no blogId
      })
    ).subscribe((blog: IBlogDT | null | undefined) => {
      if (!blog) {
        // blog not found, navigate to 404 page
        this.router.navigate(['/404']);
      } else {
        this.blog = blog;
      }
    });
  }
}
