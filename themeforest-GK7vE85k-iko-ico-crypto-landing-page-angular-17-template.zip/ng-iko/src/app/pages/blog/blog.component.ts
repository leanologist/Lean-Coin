import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HeaderThreeComponent } from '../../shared/layout/header/header-three/header-three.component';
import { BreadcrumbComponent } from '../../shared/components/breadcrumb/breadcrumb.component';
import { DocumentAreaComponent } from '../../shared/components/document-area/document-area.component';
import { FooterThreeComponent } from '../../shared/layout/footer/footer-three/footer-three.component';
import { BlogMasonryComponent } from '../../shared/components/blog/blog-single/blog-masonry/blog-masonry.component';
import { BlogStandardComponent } from '../../shared/components/blog/blog-single/blog-standard/blog-standard.component';
import { BlogSidebarComponent } from '../../shared/components/blog/blog-sidebar/blog-sidebar.component';
import { PaginationService } from '../../shared/services/pagination.service';
import { PaginationComponent } from '../../shared/components/pagination/pagination.component';
import { UtilsService } from '../../shared/services/utils.service';
import { IBlogDT } from '../../shared/types/blog-d-t';

@Component({
  selector: 'app-blog',
  standalone: true,
  imports: [
    CommonModule,
    HeaderThreeComponent,
    BreadcrumbComponent,
    DocumentAreaComponent,
    FooterThreeComponent,
    BlogMasonryComponent,
    BlogStandardComponent,
    BlogSidebarComponent,
    PaginationComponent,
  ],
  templateUrl: './blog.component.html',
  styleUrl: './blog.component.css'
})
export class BlogComponent {
  public blogs: IBlogDT[] = [];
  public pageSize: number = 3;
  public paginate: any = {};
  public pageNo: number = 1;

  constructor(
    public paginationService: PaginationService,
    public utilsService: UtilsService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.pageNo = params['page'] ? params['page'] : this.pageNo;
      this.utilsService.blogs.subscribe((response) => {
        this.blogs = response;
        this.paginate = this.paginationService.getPager(this.blogs.length, Number(+this.pageNo), this.pageSize);
        this.blogs = this.blogs.slice(this.paginate.startIndex, this.paginate.endIndex + 1);
      });
    });
  }
  

  setPage(page: number) {
    this.router
      .navigate([], {
        relativeTo: this.route,
        queryParams: { page: page },
        queryParamsHandling: 'merge',
        skipLocationChange: false,
      })
      .finally(() => {
        window.scrollTo(0, 0);
      });
  }
}
