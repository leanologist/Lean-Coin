import { Component } from '@angular/core';
import { HeaderOneComponent } from '../../../shared/layout/header/header-one/header-one.component';
import { HeroOneComponent } from '../../../shared/components/hero/hero-one/hero-one.component';
import { BrandOneComponent } from '../../../shared/components/brand/brand-one/brand-one.component';
import { WhyChooseOneComponent } from '../../../shared/components/why-choose/why-choose-one/why-choose-one.component';
import { IntroAreaOneComponent } from '../../../shared/components/intro/intro-area-one/intro-area-one.component';
import { RoadmapOneComponent } from '../../../shared/components/roadmap/roadmap-one/roadmap-one.component';
import { InvestAreaComponent } from '../../../shared/components/invest-area/invest-area.component';
import { TeamAreaComponent } from '../../../shared/components/team-area/team-area.component';
import { PartnersComponent } from '../../../shared/components/partners/partners.component';
import { EventsComponent } from '../../../shared/components/events/events.component';
import { FaqOneComponent } from '../../../shared/components/faq/faq-one/faq-one.component';
import { FooterOneComponent } from '../../../shared/layout/footer/footer-one/footer-one.component';
import { UtilsService } from '../../../shared/services/utils.service';

@Component({
  selector: 'app-home-main',
  standalone: true,
  imports: [
    HeaderOneComponent,
    HeroOneComponent,
    BrandOneComponent,
    WhyChooseOneComponent,
    IntroAreaOneComponent,
    RoadmapOneComponent,
    InvestAreaComponent,
    TeamAreaComponent,
    PartnersComponent,
    EventsComponent,
    FaqOneComponent,
    FooterOneComponent,
  ],
  templateUrl: './home-main.component.html',
  styleUrl: './home-main.component.css',
})
export class HomeMainComponent {

  constructor(public utilsService: UtilsService) {};
  
}
