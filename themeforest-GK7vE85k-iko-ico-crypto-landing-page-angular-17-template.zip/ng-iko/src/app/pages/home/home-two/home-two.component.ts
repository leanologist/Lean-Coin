import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { HeaderTwoComponent } from '../../../shared/layout/header/header-two/header-two.component';
import { HeroTwoComponent } from '../../../shared/components/hero/hero-two/hero-two.component';
import { BrandTwoComponent } from '../../../shared/components/brand/brand-two/brand-two.component';
import { FeatureOneComponent } from '../../../shared/components/feature/feature-one/feature-one.component';
import { FeatureTwoComponent } from '../../../shared/components/feature/feature-two/feature-two.component';
import { FeatureThreeComponent } from '../../../shared/components/feature/feature-three/feature-three.component';
import { TestimonialComponent } from '../../../shared/components/testimonial/testimonial.component';
import { CtaOneComponent } from '../../../shared/components/cta/cta-one/cta-one.component';
import { FaqTwoComponent } from '../../../shared/components/faq/faq-two/faq-two.component';
import { CtaTwoComponent } from '../../../shared/components/cta/cta-two/cta-two.component';
import { FooterTwoComponent } from '../../../shared/layout/footer/footer-two/footer-two.component';
import { UtilsService } from '../../../shared/services/utils.service';

@Component({
  selector: 'app-home-two',
  standalone: true,
  imports: [
    CommonModule,
    HeaderTwoComponent,
    HeroTwoComponent,
    BrandTwoComponent,
    FeatureOneComponent,
    FeatureTwoComponent,
    FeatureThreeComponent,
    TestimonialComponent,
    CtaOneComponent,
    FaqTwoComponent,
    CtaTwoComponent,
    FooterTwoComponent,
  ],
  templateUrl: './home-two.component.html',
  styleUrl: './home-two.component.css',
})
export class HomeTwoComponent {
  constructor(public utilsService: UtilsService) {};
}
