import { Component } from '@angular/core';
import blog_data from '../../../data/blog-data';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-blog-sidebar',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './blog-sidebar.component.html',
  styleUrl: './blog-sidebar.component.css'
})
export class BlogSidebarComponent {

  public recent_posts = [...blog_data].slice(-3);
}
