import { Component, Input } from '@angular/core';
import { IBlogDT } from '../../../../types/blog-d-t';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-blog-masonry',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './blog-masonry.component.html',
  styleUrl: './blog-masonry.component.css'
})
export class BlogMasonryComponent {

  @Input() blog!: IBlogDT;
}
