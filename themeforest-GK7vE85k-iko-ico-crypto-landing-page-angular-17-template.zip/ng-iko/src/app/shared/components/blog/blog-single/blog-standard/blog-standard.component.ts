import { Component, Input } from '@angular/core';
import { IBlogDT } from '../../../../types/blog-d-t';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-blog-standard',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './blog-standard.component.html',
  styleUrl: './blog-standard.component.css'
})
export class BlogStandardComponent {

  @Input() blog!: IBlogDT;
}
