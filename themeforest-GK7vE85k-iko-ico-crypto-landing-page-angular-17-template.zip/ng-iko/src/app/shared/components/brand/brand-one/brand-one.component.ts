import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import Swiper from 'swiper';

@Component({
  selector: 'app-brand-one',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './brand-one.component.html',
  styleUrl: './brand-one.component.css'
})
export class BrandOneComponent {

  public brands = [
    '/assets/img/brand/brand_img01.png',
    '/assets/img/brand/brand_img02.png',
    '/assets/img/brand/brand_img03.png',
    '/assets/img/brand/brand_img04.png',
    '/assets/img/brand/brand_img05.png',
    '/assets/img/brand/brand_img06.png',
    '/assets/img/brand/brand_img07.png',
    '/assets/img/brand/brand_img04.png',
  ];

  ngOnInit() {
    new Swiper('.brand-active2', {
      slidesPerView: 5,
      spaceBetween: 0,
      loop: false,
      breakpoints: {
        '1200': {
          slidesPerView: 5,
        },
        '992': {
          slidesPerView: 4,
        },
        '768': {
          slidesPerView: 3,
        },
        '576': {
          slidesPerView: 2,
        },
        '0': {
          slidesPerView: 2,
        },
      },
    });
  }
}
