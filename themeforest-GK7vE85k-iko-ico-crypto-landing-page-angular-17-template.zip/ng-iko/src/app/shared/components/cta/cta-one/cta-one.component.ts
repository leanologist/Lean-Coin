import { Component } from '@angular/core';
import { UtilsService } from '../../../services/utils.service';
import { CommonModule } from '@angular/common';
import { VideoPopupComponent } from '../../video-popup/video-popup.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-cta-one',
  standalone: true,
  imports: [CommonModule,VideoPopupComponent,RouterModule],
  templateUrl: './cta-one.component.html',
  styleUrl: './cta-one.component.css'
})
export class CtaOneComponent {

  constructor(public utilsService: UtilsService){}
}
