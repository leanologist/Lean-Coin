import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import Swiper from 'swiper';
import { Pagination } from 'swiper/modules';

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './events.component.html',
  styleUrl: './events.component.css'
})
export class EventsComponent {

  public event_data = [
    {
      img: '/assets/img/update/event/1-1.png',
      title: 'BlockVienna',
      location:'Venna',
      date:'August 17, 2024'
    },
    {
      img: '/assets/img/update/event/1-2.png',
      title: 'Summit Summits',
      location:'USA',
      date:'June 12, 2024'
    },
    {
      img: '/assets/img/update/event/1-3.png',
      title: 'Blockchain Summit',
      location:'America',
      date:'July 07, 2024'
    },
    {
      img: '/assets/img/update/event/1-4.png',
      title: 'Economy ICO 2024',
      location:'Costa Rica',
      date:'September 09, 2024'
    },
    {
      img: '/assets/img/update/event/1-5.png',
      title: 'Blockchain summit',
      location:'Brazil',
      date:'April 15, 2024'
    },
    {
      img: '/assets/img/update/event/1-6.png',
      title: 'Blockchain & bitcoin',
      location:'Argentina',
      date:'August 16, 2024'
    },
    {
      img: '/assets/img/update/event/1-7.png',
      title: 'Money conference',
      location:'France',
      date:'May 13, 2024'
    },
    {
      img: '/assets/img/update/event/1-8.png',
      title: 'Crypto Economy',
      location:'Saudi Arabia',
      date:'April 20, 2024'
    }
  ];

  public press_data = [
    {
      img: '/assets/img/update/client/press-1-1.svg',
      title: 'huffpost.com',
      desc:'UniFox seeks to incorporate cryptocurrencies into everyday life through the introduction of their autonomous design.'
    },
    {
      img: '/assets/img/update/client/press-1-2.svg',
      title: 'msnbc.com',
      desc:'In excellence from Tether or love another "stable" crippling. Unicash can easily be converted to local currency by special bankers '
    },
    {
      img: '/assets/img/update/client/press-1-1.svg',
      title: 'huffpost.com',
      desc:'UniFox seeks to incorporate cryptocurrencies into everyday life through the introduction of their autonomous design.'
    },
    {
      img: '/assets/img/update/client/press-1-2.svg',
      title: 'msnbc.com',
      desc:'In excellence from Tether or love another "stable" crippling. Unicash can easily be converted to local currency by special bankers '
    }
  ];

  ngOnInit() {
    new Swiper('.cta-slider1', {
      slidesPerView: 2,
      spaceBetween: 30,
      loop: false,
      pagination: {
        clickable: true,
        el:'.ns-swiper-dot-2',
      },
      modules: [Pagination],
      breakpoints: {
        '992': {
          slidesPerView: 2,
        },
        '768': {
          slidesPerView: 2,
        },
        '576': {
          slidesPerView: 1,
        },
        '0': {
          slidesPerView: 1,
        },
      },
    });
  }
}
