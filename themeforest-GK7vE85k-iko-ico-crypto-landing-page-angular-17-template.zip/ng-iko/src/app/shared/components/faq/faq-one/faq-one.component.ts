import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-faq-one',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './faq-one.component.html',
  styleUrl: './faq-one.component.css'
})
export class FaqOneComponent {

  public faq_data = [
    {
      id:1,
      active:true,
      question: 'How to buy FOX tokens?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:2,
      question: 'What is the value of FOX tokens?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:3,
      question: 'What is the value of FOX tokens?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:4,
      question: 'How are coins distribut ed?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:5,
      question: 'How to buy FOX tokens?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:6,
      question: 'What is the value of FOX tokens?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:7,
      question: 'What is the value of FOX tokens?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    }
  ]
}
