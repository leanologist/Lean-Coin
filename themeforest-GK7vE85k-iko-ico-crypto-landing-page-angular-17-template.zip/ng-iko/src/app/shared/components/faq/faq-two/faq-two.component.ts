import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-faq-two',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './faq-two.component.html',
  styleUrl: './faq-two.component.css'
})
export class FaqTwoComponent {

  public faq_data = [
    {
      id:1,
      active:true,
      question: 'What is blockchain technology?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:2,
      question: 'What is Bitcoin?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:3,
      question: 'Who created Bitcoin?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:4,
      question: 'What is cryptocurrency?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    },
    {
      id:5,
      question: 'How does cryptocurrency  work?',
      answer: 'It\'s very simple! Register here. In your personal account, create a wallet where you can store your FOX tokens. Then just send any amount to the displayed address in your office.'
    }
  ]
}
