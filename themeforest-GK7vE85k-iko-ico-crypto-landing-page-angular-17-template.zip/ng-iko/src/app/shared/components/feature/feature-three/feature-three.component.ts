import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-feature-three',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './feature-three.component.html',
  styleUrl: './feature-three.component.css'
})
export class FeatureThreeComponent {

}
