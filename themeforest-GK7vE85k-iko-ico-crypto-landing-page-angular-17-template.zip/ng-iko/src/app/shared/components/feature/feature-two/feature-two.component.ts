import { Component } from '@angular/core';

@Component({
  selector: 'app-feature-two',
  standalone: true,
  imports: [],
  templateUrl: './feature-two.component.html',
  styleUrl: './feature-two.component.css'
})
export class FeatureTwoComponent {

}
