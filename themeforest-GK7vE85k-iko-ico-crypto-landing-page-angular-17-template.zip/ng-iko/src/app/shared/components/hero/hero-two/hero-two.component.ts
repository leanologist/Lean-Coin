import { Component } from '@angular/core';

@Component({
  selector: 'app-hero-two',
  standalone: true,
  imports: [],
  templateUrl: './hero-two.component.html',
  styleUrl: './hero-two.component.css'
})
export class HeroTwoComponent {

}
