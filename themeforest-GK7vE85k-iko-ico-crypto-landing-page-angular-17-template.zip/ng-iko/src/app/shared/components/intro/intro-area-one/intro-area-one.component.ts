import { Component } from '@angular/core';

@Component({
  selector: 'app-intro-area-one',
  standalone: true,
  imports: [],
  templateUrl: './intro-area-one.component.html',
  styleUrl: './intro-area-one.component.css'
})
export class IntroAreaOneComponent {

}
