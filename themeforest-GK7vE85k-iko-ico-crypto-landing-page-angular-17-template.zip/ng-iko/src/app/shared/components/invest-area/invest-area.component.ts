import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-invest-area',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './invest-area.component.html',
  styleUrl: './invest-area.component.css'
})
export class InvestAreaComponent {

  public invest_data = [
    {
      icon:'/assets/img/update/invest/invest-icon-1.png',
      title:'Enclose BTC',
    },
    {
      icon:'/assets/img/update/invest/invest-icon-2.png',
      title:'Enclose ETH',
    },
    {
      icon:'/assets/img/update/invest/invest-icon-3.png',
      title:'Bank Transfer',
    },
    {
      icon:'/assets/img/update/invest/invest-icon-4.png',
      title:'Enclose UXC',
    }
  ]
}
