import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import Swiper from 'swiper';
import { Pagination } from 'swiper/modules';

@Component({
  selector: 'app-partners',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './partners.component.html',
  styleUrl: './partners.component.css'
})
export class PartnersComponent {

  public partner_data = [
    {
      img: '/assets/img/update/client/client-1-4.svg',
      text: 'Stable crypto currency and an important part of the UniFox ecosystem'
    },
    {
      img: '/assets/img/update/client/client-1-2.svg',
      text: 'Online exchanger, specializing in the exchange of private individuals'
    },
    {
      img: '/assets/img/update/client/client-1-5.svg',
      text: 'A company that provides all IT services within the ecosystem of UniFox'
    },
    {
      img: '/assets/img/update/client/client-1-4.svg',
      text: 'Stable crypto currency and an important part of the UniFox ecosystem'
    },
    {
      img: '/assets/img/update/client/client-1-2.svg',
      text: 'Online exchanger, specializing in the exchange of private individuals'
    },
    {
      img: '/assets/img/update/client/client-1-5.svg',
      text: 'A company that provides all IT services within the ecosystem of UniFox'
    }
  ];

  ngOnInit() {
    new Swiper('.partner-slider1', {
      slidesPerView: 3,
      spaceBetween: 30,
      loop: false,
      pagination: {
        clickable: true,
        el:'.ns-swiper-dot-1',
      },
      modules: [Pagination],
      breakpoints: {
        '1200': {
          slidesPerView: 3,
        },
        '992': {
          slidesPerView: 3,
        },
        '768': {
          slidesPerView: 2,
        },
        '576': {
          slidesPerView: 1,
        },
        '0': {
          slidesPerView: 1,
        },
      },
    });
  }
}
