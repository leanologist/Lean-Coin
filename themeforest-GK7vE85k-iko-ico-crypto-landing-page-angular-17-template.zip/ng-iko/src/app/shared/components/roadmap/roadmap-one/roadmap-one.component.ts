import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import Swiper from 'swiper';

@Component({
  selector: 'app-roadmap-one',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './roadmap-one.component.html',
  styleUrl: './roadmap-one.component.css'
})
export class RoadmapOneComponent {

  public roadmap_items = [
    {
      subtitle: 'End of Q4 2023',
      title: 'Research',
      desc:'SubQuery Builders/Grants Program SQT Network contract internal MVP Coordinator and client SDK implementations'
    },
    {
      subtitle: 'End of Q4 2023',
      title: 'App Beta Test',
      desc:'SubQuery Builders/Grants Program SQT Network contract internal MVP Coordinator and client SDK implementations'
    },
    {
      subtitle: 'End of Q4 2023',
      title: 'Token Test',
      desc:'SubQuery Builders/Grants Program SQT Network contract internal MVP Coordinator and client SDK implementations'
    },
    {
      subtitle: 'End of Q4 2023',
      title: 'Alpha Test',
      desc:'SubQuery Builders/Grants Program SQT Network contract internal MVP Coordinator and client SDK implementations'
    },
    {
      subtitle: 'End of Q4 2023',
      title: 'Concept',
      desc:'SubQuery Builders/Grants Program SQT Network contract internal MVP Coordinator and client SDK implementations'
    }
  ];

  public swiperInstance: Swiper | undefined;

  ngOnInit() {
    this.swiperInstance = new Swiper('.roadMap-active2', {
      slidesPerView: 4,
      spaceBetween: 0,
      loop: true,
      breakpoints: {
        '1400': {
          slidesPerView: 4,
        },
        '1200': {
          slidesPerView: 3,
        },
        '992': {
          slidesPerView: 3,
        },
        '768': {
          slidesPerView: 2,
        },
        '576': {
          slidesPerView: 1,
        },
        '0': {
          slidesPerView: 1,
        },
      },
    });
  }
}
