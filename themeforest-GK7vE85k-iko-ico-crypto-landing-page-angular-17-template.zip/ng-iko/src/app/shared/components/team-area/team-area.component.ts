import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-team-area',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './team-area.component.html',
  styleUrl: './team-area.component.css'
})
export class TeamAreaComponent {

  public activeCat = 'advisory';
  handleCategory(cat: string) {
    this.activeCat = cat;
  };
  get filterItems() {
    if (this.activeCat === 'advisory') {
      return this.team_data.filter((item) => item.category === 'advisory');
    } else if(this.activeCat === 'management') {
      return this.team_data.filter((item) => item.category === 'management');
    } else if(this.activeCat === 'marketing') {
      return this.team_data.filter((item) => item.category === 'marketing');
    } else {
      return this.team_data;
    }
  }
  public founders = [
    {
      img: 'assets/img/update/team/founder-1-1.png',
      name: 'Eleanor Pena',
      designation: 'Founder & CEO',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        },
        {
          link: 'https://youtube.com/',
          icon: 'fab fa-youtube'
        },
        {
          link: 'https://facebook.com/',
          icon: 'fab fa-facebook'
        }
      ]
    },
    {
      img: 'assets/img/update/team/founder-1-2.png',
      name: 'Eleanor Pena',
      designation: 'Founder & CEO',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        },
        {
          link: 'https://youtube.com/',
          icon: 'fab fa-youtube'
        },
        {
          link: 'https://facebook.com/',
          icon: 'fab fa-facebook'
        }
      ]
    }
  ];

  public team_data = [
    {
      id:1,
      img: '/assets/img/update/team/team-1-1.png',
      name: 'Jacob Jones',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:2,
      img: '/assets/img/update/team/team-1-2.png',
      name: 'Albert Flores',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:3,
      img: '/assets/img/update/team/team-1-3.png',
      name: 'Devon Lane',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:4,
      img: '/assets/img/update/team/team-1-4.png',
      name: 'Jacob Jones',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:5,
      img: '/assets/img/update/team/team-1-5.png',
      name: 'Bradley Hunter',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:6,
      img: '/assets/img/update/team/team-1-6.png',
      name: 'Eleanor Pena',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:7,
      img: '/assets/img/update/team/team-1-7.png',
      name: 'Christopher Nolan',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:8,
      img: '/assets/img/update/team/team-1-8.png',
      name: 'Devon Lane',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:9,
      img: '/assets/img/update/team/team-1-9.png',
      name: 'Floyd Miles',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    {
      id:10,
      img: '/assets/img/update/team/team-1-10.png',
      name: 'Gerald Rivera',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'advisory'
    },
    // management
    {
      id:11,
      img: '/assets/img/update/team/team-1-4.png',
      name: 'Eleanor Pena',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'management'
    },
    {
      id:12,
      img: '/assets/img/update/team/team-1-3.png',
      name: 'Gerald Rivera',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'management'
    },
    {
      id:13,
      img: '/assets/img/update/team/team-1-5.png',
      name: 'Harriett Bridges',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'management'
    },
    {
      id:14,
      img: '/assets/img/update/team/team-1-9.png',
      name: 'Irma Dorsey',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'management'
    },
    {
      id:15,
      img: '/assets/img/update/team/team-1-7.png',
      name: 'Irma Dorsey',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'management'
    },
    // marketing
    {
      id:16,
      img: '/assets/img/update/team/team-1-10.png',
      name: 'Jacob Jones',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'marketing'
    },
    {
      id:17,
      img: '/assets/img/update/team/team-1-6.png',
      name: 'Kevin Vasquez',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'marketing'
    },
    {
      id:18,
      img: '/assets/img/update/team/team-1-5.png',
      name: 'Leonard Watson',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'marketing'
    },
    {
      id:19,
      img: '/assets/img/update/team/team-1-7.png',
      name: 'Natalie Myers',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'marketing'
    },
    {
      id:20,
      img: '/assets/img/update/team/team-1-1.png',
      name: 'Matthew Cooper',
      social: [
        {
          link: 'https://www.linkedin.com/',
          icon: 'fab fa-linkedin'
        }
      ],
      category:'marketing'
    }
  ]
}
