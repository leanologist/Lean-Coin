import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import Swiper from 'swiper';

@Component({
  selector: 'app-testimonial',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './testimonial.component.html',
  styleUrl: './testimonial.component.css'
})
export class TestimonialComponent {

  public testimonial_data = [
    {
      name: 'Romero Eli',
      designation: 'Developer',
      rating: 5,
      text: 'I\'ve tested numerous technologies, but this one is leaps and bounds ahead of the competition. It\'s phenomenal.',
      image: '/assets/img/update/testimonial/testi_thumb1_1.png',
    },
    {
      name: 'Gierre Goles',
      designation: 'Product Designers',
      rating: 5,
      text: 'I can\'t express how impressed I am with this technology. It outshines anything I\'ve ever used before & up to the mark.',
      image: '/assets/img/update/testimonial/testi_thumb1_2.png',
    },
    {
      name: 'Benjamin Smith',
      designation: 'Marketer',
      rating: 5,
      text: 'I\'ve tested numerous technologies, but this one is leaps and bounds ahead of the competition. It\'s phenomenal.',
      image: '/assets/img/update/testimonial/testi_thumb1_1.png',
    },
    {
      name: 'Vincent Smith',
      designation: 'Designer',
      rating: 5,
      text: 'I can\'t express how impressed I am with this technology. It outshines anything I\'ve ever used before & up to the mark.',
      image: '/assets/img/update/testimonial/testi_thumb1_2.png',
    }
  ];

  public swiperInstance: Swiper | undefined;

  ngOnInit() {
    this.swiperInstance = new Swiper('.testimonial-slider1', {
      slidesPerView: 2,
      spaceBetween: 150,
      loop: false,
      breakpoints: {
        '1400': {
          slidesPerView: 2,
        },
        '1200': {
          slidesPerView: 2,
        },
        '992': {
          slidesPerView: 2,
        },
        '768': {
          slidesPerView: 1,
        },
        '576': {
          slidesPerView: 1,
        },
        '0': {
          slidesPerView: 1,
        },
      },
    });
  }
}
