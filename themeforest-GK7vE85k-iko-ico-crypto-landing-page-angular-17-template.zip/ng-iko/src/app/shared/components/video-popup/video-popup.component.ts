import { Component } from '@angular/core';
import { UtilsService } from '../../services/utils.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-video-popup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './video-popup.component.html',
  styleUrl: './video-popup.component.css'
})
export class VideoPopupComponent {

  constructor(public utilsService: UtilsService){}
}
