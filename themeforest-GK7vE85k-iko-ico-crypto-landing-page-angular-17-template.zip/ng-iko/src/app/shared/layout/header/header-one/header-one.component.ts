import { CommonModule, ViewportScroller } from '@angular/common';
import { Component, ElementRef, HostListener } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, RouterModule } from '@angular/router';
import { UtilsService } from '../../../services/utils.service';
import { MobileOffcanvasComponent } from '../../../components/mobile-offcanvas/mobile-offcanvas.component';

@Component({
  selector: 'app-header-one',
  standalone: true,
  imports: [CommonModule,RouterModule,MobileOffcanvasComponent],
  templateUrl: './header-one.component.html',
  styleUrl: './header-one.component.css'
})
export class HeaderOneComponent {

  constructor(public utilsService:UtilsService,private router: Router) {};
  
  scrollToFragment(fragment: string): void {
    setTimeout(() => {
      const element = document.getElementById(fragment);
      if (element) {
        const offsetTop = element.offsetTop - 60;
        console.log('element offset',element,offsetTop);
        window.scrollTo({ top: offsetTop, behavior: 'smooth' });
      }
    }, 100);
  }

  navigateWithOffset(fragment: string): void {
    this.router.navigate(['/home'], { fragment: fragment });
    this.scrollToFragment(fragment);
  }


  isFeatureRouteActive(): boolean {
    return this.router.url === '/home#feature';
  }

  isRoadMapRouteActive(): boolean {
    return this.router.url === '/home#roadMap';
  }

  public sticky: boolean = false;
  // sticky nav
  @HostListener('window:scroll', ['$event']) onscroll() {
    if (window.scrollY > 100) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
  };


}
