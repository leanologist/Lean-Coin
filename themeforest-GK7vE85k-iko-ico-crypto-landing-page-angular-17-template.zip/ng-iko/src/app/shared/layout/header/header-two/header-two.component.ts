import { CommonModule } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { MobileOffcanvasComponent } from '../../../components/mobile-offcanvas/mobile-offcanvas.component';
import { UtilsService } from '../../../services/utils.service';

@Component({
  selector: 'app-header-two',
  standalone: true,
  imports: [CommonModule,RouterModule,MobileOffcanvasComponent],
  templateUrl: './header-two.component.html',
  styleUrl: './header-two.component.css'
})
export class HeaderTwoComponent {

  constructor(public utilsService:UtilsService,private router: Router) {};
  
  scrollToFragment(fragment: string): void {
    setTimeout(() => {
      const element = document.getElementById(fragment);
      if (element) {
        const offsetTop = element.offsetTop - 60;
        console.log('element offset',element,offsetTop);
        window.scrollTo({ top: offsetTop, behavior: 'smooth' });
      }
    }, 100);
  }

  navigateWithOffset(fragment: string): void {
    this.router.navigate(['/home/home-two'], { fragment: fragment });
    this.scrollToFragment(fragment);
  }

  isFeatureRouteActive(): boolean {
    return this.router.url === '/home/home-two#feature';
  }

  isBlockchainRouteActive(): boolean {
    return this.router.url === '/home/home-two#blockchain';
  }

  public sticky: boolean = false;
  // sticky nav
  @HostListener('window:scroll', ['$event']) onscroll() {
    if (window.scrollY > 100) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
  }
}
