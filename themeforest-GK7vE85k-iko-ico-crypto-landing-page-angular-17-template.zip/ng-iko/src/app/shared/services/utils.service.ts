import { Injectable } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Observable, map, of } from 'rxjs';
import { IBlogDT } from '../types/blog-d-t';
import blog_data from '../data/blog-data';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {

  constructor(
    private router: Router
  ) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.openMobileMenus = false;
      }
    });
  }

  // video modal
  public videoUrl: string = 'https://www.youtube.com/embed/EW4ZYb3mCZk';
  public isVideoOpen: boolean = false;
  public openMobileMenus: boolean = false;
  public openOffcanvas: boolean = false;
  public iframeElement: HTMLIFrameElement | null = null;

  // open mobile sidebar
  handleOpenMobileMenu() {
    this.openMobileMenus = !this.openMobileMenus;
  };

  // modal video play
  playVideo(videoId: string) {
    const videoOverlay = document.querySelector('#video-overlay');
    this.videoUrl = `https://www.youtube.com/embed/${videoId}`;
    if (!this.iframeElement) {
      this.iframeElement = document.createElement('iframe');
      this.iframeElement.setAttribute('src', this.videoUrl);
      this.iframeElement.style.width = '60%';
      this.iframeElement.style.height = '80%';
    }

    this.isVideoOpen = true;
    videoOverlay?.classList.add('open');
    videoOverlay?.appendChild(this.iframeElement);
  }
  // close modal video
  closeVideo() {
    const videoOverlay = document.querySelector('#video-overlay.open');

    if (this.iframeElement) {
      this.iframeElement.remove();
      this.iframeElement = null;
    }

    this.isVideoOpen = false;
    videoOverlay?.classList.remove('open');
  };

  // Get blogs
  public get blogs(): Observable<IBlogDT[]> {
    return of(blog_data);
  };

  // Get blog By id
  public getBlogById(id: string): Observable<IBlogDT | undefined> {
    return this.blogs.pipe(map(items => {
      const blog = items.find(p => Number(p.id) === Number(id));
      return blog;
    }));
  }

}
