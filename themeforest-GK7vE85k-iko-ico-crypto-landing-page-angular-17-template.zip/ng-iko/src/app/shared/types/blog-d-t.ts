export interface IBlogDT {
  id: number
  title: string
  img: string
  date: string
  desc: string
  author: string
  author_name: string
  comment: number
  view: number,
  blog_masonry?: boolean,
  blog_standard?: boolean
}